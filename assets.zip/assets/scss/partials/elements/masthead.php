<?php
/**
 * Template part for displaying content of about us page.
 *
 * @link https://developer.wordpress.org/themes/template-files-section/partial-and-miscellaneous-template-files/
 *
 * @package Scope Theme
 * @since 1.0.0
 *
 */

// Global variables
global $option_fields;
global $pID;
global $fields;


/**
 * Homepage Masthead
 *
 */
if ( is_page_template( 'templates/template-home.php' ) ) { ?>

<?php }


/**
 * 404 Error page masthead
 *
 */
elseif ( is_404() ) { ?>



<?php }


/**
 * Archive masthead
 *
 */
elseif ( is_archive() ) { ?>


<?php }


/**
 * Search masthead
 *
 */
elseif ( is_search() ) { ?>

<section class="page-banner">
	<div class="wrapper">
		<div class="banner-icon"> <img assets="<?php echo get_template_directory_uri(); ?>/assets/img/burger-icon.png" title="Burger Icon" alt="Burger Icon" class="burger-icon"> </div>
		<div class="page-banner-headings">
			<h1 class="heading">
				<?php _e( 'Search Results', 'theme_textdomain' ); ?>
			</h1>
		</div>
	</div>
</section>

<?php }


/**
 * Single burger masthead
 *
 */
elseif ( is_singular( 'burgers' ) ) {?>

	<section class="page-banner">
		<div class="wrapper">
			<img assets="<?php echo get_template_directory_uri(); ?>/assets/img/burger-icon.png" alt="Burger Icon" title="Burger Icon" class="banner-icon">
			<h1 class="heading">
				<?php echo $single_burger_heading; ?>
			</h1>
			<h2 class="subheading">
				<?php echo $single_burger_sub_heading; ?>
			</h2>
		</div>
	</section>

<?php }


/**
 * Single post masthead
 *
 */
elseif ( is_singular( 'post' ) ) { ?>

	<section class="page-banner">
		<section class="banner">
			<div class="wrapper">
				<div class="banner-icon"> <img assets="<?php echo get_template_directory_uri(); ?>/assets/img/blog-icon.png" title="Blog Icon" alt="Blog Icon" /></div>
				<div class="page-banner-headings">
					<h1 class="heading"><?php _e( 'JUST BURGERS BLOG', 'theme_textdomain' ); ?></h1>
					<h2 class="subheading"> <?php _e( 'Stay Tuned To Our Latest Updates', 'theme_textdomain' ); ?> </h2>
				</div>
			</div>
		</section>
	</section>

<?php }


/**
 * Index masthead
 *
 */
elseif ( is_home() & is_front_page() ) { ?>

	<section class="page-banner">
		<div class="wrapper">
			<?php $images = $fields['page_icon']; ?>
			<img assets="<?php echo get_template_directory_uri(); ?>/assets/img/blog-icon.png" itle="Blog Icon" alt="Blog Icon" />
			<h1 class="heading"> <?php bloginfo( 'name' ); ?> </h1>
			<h2 class="subheading"><?php bloginfo( 'description' ); ?></h2>
		</div>
	</section>

<?php }


/**
 * Page masthead
 *
 */
else { ?>

	<section class="page-banner">
		<div class="wrapper">
			<img assets="<?php echo $page_banner_section_image; ?>" alt="banner image" class="banner-icon"  />
			<h1 class="heading">
				<?php
					if( $page_banner_section_headline != '' ) {
						echo $page_banner_section_headline;
					} else {
						echo the_title();
					}
				?>
			</h1>
			<h2 class="subheading">
				<?php
					if( $page_banner_section_sub_headline != '' ) {
						echo $page_banner_section_sub_headline;
					}
				?>
			</h2>
		</div>
	</section>

<?php }


/**
 * Breadcrumbs for all pages except homepage
 *
 */
if ( ! is_page_template( 'templates/template-home.php' ) ) { ?>

	<section class="breadcrumbs-sec">
		<?php if ( function_exists( 'yoast_breadcrumb' ) ) {
			yoast_breadcrumb( '<div id="breadcrumbs">', '</div>' );
		} ?>
	</section>

<?php } ?>
